SELECT 
    v.Venue_Name,
    COUNT(DISTINCT m.Match_Id) AS Matches_Played,
    ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Score_Per_Match
FROM Ball_by_Ball b
JOIN Matches m ON b.Match_Id = m.Match_Id
JOIN Venue v ON m.Venue_Id = v.Venue_Id
GROUP BY v.Venue_Name
HAVING Matches_Played > 20
ORDER BY Avg_Score_Per_Match DESC;
