-- A For Batsmen –  Average Runs per Match
SELECT 
    p.Player_Name,
    COUNT(DISTINCT b.Match_Id) AS Matches_Played,
    SUM(b.Runs_Scored) AS Total_Runs,
    ROUND(SUM(b.Runs_Scored) * 1.0 / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match
FROM Ball_by_Ball b
JOIN Player p ON p.Player_Id = b.Striker
GROUP BY p.Player_Name
ORDER BY Avg_Runs_Per_Match DESC
LIMIT 10;

--  Strike Rate (Runs per 100 balls)
SELECT 
    p.Player_Name,
    COUNT(*) AS Balls_Faced,
    SUM(b.Runs_Scored) AS Runs,
    ROUND(SUM(b.Runs_Scored) * 100.0 / COUNT(*), 2) AS Strike_Rate
FROM Ball_by_Ball b
JOIN Player p ON p.Player_Id = b.Striker
GROUP BY p.Player_Name
HAVING COUNT(*) > 50
ORDER BY Strike_Rate DESC
LIMIT 10;

--  Season Experience
SELECT 
    p.Player_Name,
    COUNT(DISTINCT s.Season_Year) AS Seasons_Played
FROM Ball_by_Ball b
JOIN Player p ON p.Player_Id = b.Striker
JOIN Matches m ON b.Match_Id = m.Match_Id
JOIN Season s ON s.Season_Id = m.Season_Id
GROUP BY p.Player_Name
ORDER BY Seasons_Played DESC
LIMIT 10;


-- B. For Bowlers –  Wickets Taken + Strike Rate
SELECT 
    p.Player_Name,
    COUNT(*) AS Deliveries_Bowled,
    COUNT(w.Match_Id) AS Wickets,
    ROUND(COUNT(w.Match_Id) * 100.0 / COUNT(*), 2) AS Strike_Rate
FROM Ball_by_Ball b
JOIN Player p ON p.Player_Id = b.Bowler
LEFT JOIN wicket_taken w 
    ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id
GROUP BY p.Player_Name
HAVING COUNT(*) > 100
ORDER BY Wickets DESC
LIMIT 10;

-- C. For All-Rounders
-- Batting Stats:
CREATE TEMPORARY TABLE temp_batting AS
SELECT 
    b.Striker AS Player_Id,
    COUNT(DISTINCT b.Match_Id) AS Matches_Batted,
    SUM(b.Runs_Scored) AS Total_Runs
FROM Ball_by_Ball b
GROUP BY b.Striker;


--  Bowling Stats:
CREATE TEMPORARY TABLE temp_bowling AS
SELECT 
    b.Bowler AS Player_Id,
    COUNT(*) AS Balls_Bowled,
    COUNT(w.Match_Id) AS Wickets
FROM Ball_by_Ball b
LEFT JOIN wicket_taken w 
    ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id
GROUP BY b.Bowler;


--  Join Final Output
SELECT 
    p.Player_Name,
    tb.Matches_Batted,
    tb.Total_Runs,
    bw.Balls_Bowled,
    bw.Wickets
FROM Player p
JOIN temp_batting tb ON p.Player_Id = tb.Player_Id
JOIN temp_bowling bw ON p.Player_Id = bw.Player_Id
WHERE tb.Total_Runs > 200 AND bw.Wickets > 10
ORDER BY bw.Wickets DESC, tb.Total_Runs DESC
LIMIT 10;

