--  Find the last 4 seasons
SELECT Season_Id, Season_Year 
FROM season
ORDER BY Season_Year DESC
LIMIT 4;

-- Use these Season_IDs to filter matches
SELECT Match_Id 
FROM matches 
WHERE Season_Id IN (6, 7, 8, 9);

--  Final Query
SELECT 
    bb.Striker as Player_Id,
    p.Player_Name,
    SUM(bb.Runs_Scored) AS Total_Runs,
    COUNT(*) AS Balls_Faced,
    ROUND((SUM(bb.Runs_Scored) / COUNT(*)) * 100, 2) AS Strike_Rate
FROM 
    ball_by_ball bb
JOIN 
    matches m ON bb.Match_Id = m.Match_Id
JOIN 
    player p ON bb.Striker = p.Player_Id
WHERE 
    m.Season_Id IN (6, 7, 8, 9)  -- last 4 seasons
GROUP BY 
    bb.Striker
HAVING 
    Balls_Faced >= 10  -- to avoid division by zero or unfair high strike rate on low data
ORDER BY 
    Strike_Rate DESC
LIMIT 10;
