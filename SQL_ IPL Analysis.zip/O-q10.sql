SELECT 
    bs.Bowling_Skill,
    COUNT(*) AS Total_Wickets
FROM wicket_taken wt
JOIN ball_by_ball bb 
    ON wt.Match_Id = bb.Match_Id 
   AND wt.Over_Id = bb.Over_Id 
   AND wt.Ball_Id = bb.Ball_Id 
   AND wt.Innings_No = bb.Innings_No
JOIN bowling_style bs 
    ON bb.Bowler = bs.Bowling_Id
GROUP BY bs.Bowling_Skill
ORDER BY Total_Wickets DESC;
