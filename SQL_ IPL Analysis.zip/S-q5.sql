SELECT 
    p.Player_Name,
    COUNT(*) AS MOM_Awards
FROM Matches m
JOIN Player p ON m.Man_of_the_Match = p.Player_Id
GROUP BY p.Player_Name
ORDER BY MOM_Awards DESC
LIMIT 10;
