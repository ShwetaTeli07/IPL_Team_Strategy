-- Create the table Player_Avg_Runs:
CREATE TEMPORARY TABLE Player_Avg_Runs AS
SELECT 
    Striker AS Player_Id,
    CAST(AVG(Runs_Scored) AS DECIMAL(5,2)) AS Avg_Runs
FROM ball_by_ball
GROUP BY Striker;

-- Create the Player_Wickets table
CREATE TEMPORARY TABLE Player_Wickets AS
SELECT 
    bb.Bowler AS Player_Id,
    COUNT(*) AS Total_Wickets
FROM wicket_taken wt
JOIN ball_by_ball bb 
  ON wt.Match_Id = bb.Match_Id 
 AND wt.Over_Id = bb.Over_Id 
 AND wt.Ball_Id = bb.Ball_Id 
 AND wt.Innings_No = bb.Innings_No
GROUP BY bb.Bowler;

-- Store overall averages in variables
-- Save average of all players' Avg_Runs
SELECT AVG(Avg_Runs) INTO @overall_avg_runs FROM Player_Avg_Runs;

-- Save average of all players' Total_Wickets
SELECT AVG(Total_Wickets) INTO @overall_avg_wickets FROM Player_Wickets;

-- Final Query — Get All-Rounders Above Average
SELECT 
    ar.Player_Id,
    pr.Player_Name,
    ar.Avg_Runs,
    pw.Total_Wickets
FROM Player_Avg_Runs ar
JOIN Player_Wickets pw ON ar.Player_Id = pw.Player_Id
JOIN player pr ON pr.Player_Id = ar.Player_Id
WHERE ar.Avg_Runs > @overall_avg_runs
  AND pw.Total_Wickets > @overall_avg_wickets
ORDER BY ar.Avg_Runs DESC, pw.Total_Wickets DESC;
