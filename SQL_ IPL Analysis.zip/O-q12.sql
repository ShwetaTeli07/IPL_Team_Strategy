SELECT 
    Striker AS Player_Id,
    ROUND(SUM(Runs_Scored) / COUNT(*) * 100, 2) AS Strike_Rate
--  1. Player Strike Rate
FROM ball_by_ball
GROUP BY Striker
ORDER BY Strike_Rate DESC;

--  2. Bowler Economy Rate
SELECT 
    Bowler AS Player_Id,
    ROUND(SUM(Runs_Scored) / (COUNT(*) / 6), 2) AS Economy
FROM ball_by_ball
GROUP BY Bowler
ORDER BY Economy;

--   3. Best Batting Partnerships
SELECT 
    Striker, Non_Striker,
    SUM(Runs_Scored) AS Partnership_Runs
FROM ball_by_ball
GROUP BY Striker, Non_Striker
ORDER BY Partnership_Runs DESC
LIMIT 10;

-- 4 Player Consistency Index
SELECT 
    Striker AS Player_Id,
    ROUND(AVG(Runs_Scored), 2) AS Avg_Runs,
    ROUND(STDDEV(Runs_Scored), 2) AS Run_Std_Dev
FROM ball_by_ball
GROUP BY Striker
ORDER BY Avg_Runs DESC;

-- 5.Boundary Frequency
SELECT 
    Striker,
    ROUND(SUM(CASE WHEN Runs_Scored IN (4,6) THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS Boundary_Percentage
FROM ball_by_ball
GROUP BY Striker
ORDER BY Boundary_Percentage DESC;


-- 6.Performance by Match Phase (Powerplay, Middle, Death)
SELECT
    CASE 
        WHEN Over_Id BETWEEN 1 AND 6 THEN 'Powerplay'
        WHEN Over_Id BETWEEN 7 AND 15 THEN 'Middle Overs'
        ELSE 'Death Overs'
    END AS Phase,
    AVG(Runs_Scored) AS Avg_Runs_Per_Ball
FROM ball_by_ball
GROUP BY Phase;

 -- 7. Dot Ball Percentage (Bowling Pressure)
SELECT 
    Bowler,
    ROUND(SUM(CASE WHEN Runs_Scored = 0 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS Dot_Ball_Percentage
FROM ball_by_ball
GROUP BY Bowler
ORDER BY Dot_Ball_Percentage DESC;


