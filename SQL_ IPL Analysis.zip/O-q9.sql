-- Get RCB’s Team_Id
SELECT * FROM team WHERE Team_Name LIKE '%Bangalore%';

--  Create the rcb_record Table
DROP TABLE IF EXISTS rcb_record;

CREATE TABLE rcb_record AS
SELECT 
    v.Venue_Name,
    SUM(CASE 
            WHEN m.Match_Winner = 2 THEN 1 
            ELSE 0 
        END) AS Wins,
    SUM(CASE 
            WHEN (m.Team_1 = 2 OR m.Team_2 = 2) AND m.Match_Winner != 2 THEN 1 
            ELSE 0 
        END) AS Losses
FROM matches m
JOIN venue v ON m.Venue_Id = v.Venue_Id
WHERE m.Team_1 = 2 OR m.Team_2 = 2
GROUP BY v.Venue_Name;


-- View Result
SELECT * FROM rcb_record;
