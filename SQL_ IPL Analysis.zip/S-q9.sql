SELECT 
    s.Season_Year,
    SUM(CASE WHEN m.Match_Winner = 2 THEN 1 ELSE 0 END) AS Wins,
    SUM(CASE WHEN (m.Team_1 = 2 OR m.Team_2 = 2) AND m.Match_Winner != 2 THEN 1 ELSE 0 END) AS Losses,
    COUNT(*) AS Total_Matches
FROM Matches m
JOIN Season s ON m.Season_Id = s.Season_Id
WHERE m.Team_1 = 2 OR m.Team_2 = 2   -- Assuming RCB’s Team_Id = 2
GROUP BY s.Season_Year
ORDER BY s.Season_Year;


SELECT 
    m.Match_Id,
    SUM(b.Runs_Scored) AS Runs_Conceded
FROM Ball_by_Ball b
JOIN Matches m ON b.Match_Id = m.Match_Id
WHERE b.Team_Bowling = 2
GROUP BY m.Match_Id
ORDER BY m.Match_Id;
