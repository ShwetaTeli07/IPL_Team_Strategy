-- Confirm RCB’s Team ID

SELECT Team_Id, Team_Name 
FROM Team 
WHERE Team_Name LIKE '%Royal Challengers%';


-- Find all matches in Season 1 where RCB was involved

SELECT Match_Id, Team_1, Team_2
FROM Matches
WHERE Season_Id = 1
  AND (Team_1 = 2 OR Team_2 = 2);


-- Check which teams actually played in Season 1

SELECT DISTINCT Team_1 AS Team_Id FROM Matches WHERE Season_Id = 1
UNION
SELECT DISTINCT Team_2 AS Team_Id FROM Matches WHERE Season_Id = 1;


-- Verify ball-by-ball data also doesn't exist for Season 1

SELECT DISTINCT m.Season_Id
FROM Matches m
JOIN Ball_by_Ball bb ON m.Match_Id = bb.Match_Id;

