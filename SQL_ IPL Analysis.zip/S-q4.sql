--   (A) Create Batting Stats Table:
CREATE TEMPORARY TABLE temp_batting AS
SELECT 
    Striker AS Player_Id,
    SUM(Runs_Scored) AS Total_Runs
FROM Ball_by_Ball
GROUP BY Striker;

--  (B) Create Bowling Stats Table:
CREATE TEMPORARY TABLE temp_bowling AS
SELECT 
    b.Bowler AS Player_Id,
    COUNT(w.Match_Id) AS Wickets
FROM Ball_by_Ball b
LEFT JOIN wicket_taken w 
    ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id
GROUP BY b.Bowler;


--   (C) Final Join to Get Versatile Players:
SELECT 
    p.Player_Name,
    tb.Total_Runs,
    bw.Wickets
FROM Player p
JOIN temp_batting tb ON p.Player_Id = tb.Player_Id
JOIN temp_bowling bw ON p.Player_Id = bw.Player_Id
WHERE tb.Total_Runs > 200 AND bw.Wickets > 10
ORDER BY bw.Wickets DESC, tb.Total_Runs DESC
LIMIT 10;
