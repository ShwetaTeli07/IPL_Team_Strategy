SELECT 
    v.Venue_Name,
    bb.Bowler,
    COUNT(*) AS Total_Wickets,
    ROUND(COUNT(*) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Wickets_Per_Match,
    RANK() OVER (PARTITION BY v.Venue_Name ORDER BY COUNT(*) / COUNT(DISTINCT m.Match_Id) DESC) AS Bowler_Rank
FROM wicket_taken wt
JOIN ball_by_ball bb 
    ON wt.Match_Id = bb.Match_Id 
   AND wt.Over_Id = bb.Over_Id 
   AND wt.Ball_Id = bb.Ball_Id 
   AND wt.Innings_No = bb.Innings_No
JOIN matches m ON m.Match_Id = wt.Match_Id
JOIN venue v ON m.Venue_Id = v.Venue_Id
GROUP BY v.Venue_Name, bb.Bowler
ORDER BY v.Venue_Name, Bowler_Rank;
