SELECT 
    p.Player_Name,
    ROUND(SUM(b.Runs_Scored) * 1.0 / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match,
    COUNT(DISTINCT m.Season_Id) AS Seasons_Played
FROM 
    Ball_by_Ball b
JOIN Player p ON b.Striker = p.Player_Id
JOIN Matches m ON m.Match_Id = b.Match_Id
GROUP BY p.Player_Name
HAVING COUNT(DISTINCT m.Season_Id) >= 3  -- Optional: players with 3+ seasons
ORDER BY Avg_Runs_Per_Match DESC
LIMIT 5;
