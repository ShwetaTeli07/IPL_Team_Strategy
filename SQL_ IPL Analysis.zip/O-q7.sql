SELECT 
    bb.Bowler,
    COUNT(*) AS Total_Wickets,
    COUNT(DISTINCT s.Season_Year) AS Seasons_Played,
    ROUND(COUNT(*) * 1.0 / COUNT(DISTINCT s.Season_Year), 2) AS Avg_Wickets_Per_Season
FROM wicket_taken wt
JOIN ball_by_ball bb 
  ON wt.Match_Id = bb.Match_Id 
 AND wt.Over_Id = bb.Over_Id 
 AND wt.Ball_Id = bb.Ball_Id 
 AND wt.Innings_No = bb.Innings_No
JOIN matches m ON m.Match_Id = wt.Match_Id
JOIN season s ON s.Season_Id = m.Season_Id
GROUP BY bb.Bowler
ORDER BY Avg_Wickets_Per_Season DESC
LIMIT 10;
