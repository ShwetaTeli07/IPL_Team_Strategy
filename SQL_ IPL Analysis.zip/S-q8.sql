SELECT 
    v.Venue_Name,
    COUNT(*) AS Total_Matches,
    SUM(CASE WHEN m.Match_Winner = 2 THEN 1 ELSE 0 END) AS RCB_Wins,
    ROUND(SUM(CASE WHEN m.Match_Winner = 2 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS Win_Percentage
FROM Matches m
JOIN Venue v ON m.Venue_Id = v.Venue_Id
WHERE m.Team_1 = 2 OR m.Team_2 = 2  -- Assuming RCB's Team_Id is 2
GROUP BY v.Venue_Name
ORDER BY RCB_Wins DESC;
