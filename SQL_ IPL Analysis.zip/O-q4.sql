-- Get RCB’s Team_Id
SELECT Team_Id 
FROM team 
WHERE Team_Name = 'Royal Challengers Bangalore';


-- Get the Season_Id for 2013
SELECT Season_Id 
FROM season 
WHERE Season_Year = 2013;

-- Count matches RCB won in 2013
SELECT COUNT(*) AS RCB_Wins_2013
FROM matches
WHERE Match_Winner = 2      -- RCB's Team_Id
  AND Season_Id = 6;        -- 2013 season
