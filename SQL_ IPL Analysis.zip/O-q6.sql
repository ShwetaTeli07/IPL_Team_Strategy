-- Calculate total runs per batsman
SELECT Striker, SUM(Runs_Scored) AS Total_Runs
FROM ball_by_ball
GROUP BY Striker;

-- Calculate number of innings per batsman
SELECT Striker, COUNT(DISTINCT CONCAT(Match_Id, '-', Innings_No)) AS Innings_Played
FROM ball_by_ball
GROUP BY Striker;


-- ombine total runs and innings
SELECT 
    bb.Striker AS Player_Id,
    p.Player_Name,
    SUM(bb.Runs_Scored) AS Total_Runs,
    COUNT(DISTINCT CONCAT(bb.Match_Id, '-', bb.Innings_No)) AS Innings_Played,
    ROUND(SUM(bb.Runs_Scored) / COUNT(DISTINCT CONCAT(bb.Match_Id, '-', bb.Innings_No)), 2) AS Average_Runs
FROM 
    ball_by_ball bb
JOIN 
    player p ON bb.Striker = p.Player_Id
GROUP BY 
    bb.Striker
    HAVING Innings_Played >= 5
ORDER BY 
    Average_Runs DESC;
