SELECT 
    td.Toss_Name AS Toss_Decision,
    COUNT(*) AS Total_Matches,
    SUM(CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END) AS Toss_Win_And_Match_Win,
    ROUND(SUM(CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS Win_Percentage
FROM matches m
JOIN toss_decision td ON m.Toss_Decide = td.Toss_Id
GROUP BY td.Toss_Name;

--  Extract Data (Venue-wise Toss Impact)
SELECT 
    v.Venue_Name,
    td.Toss_Name AS Toss_Decision,
    COUNT(*) AS Total_Matches,
    SUM(CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END) AS Toss_Win_And_Match_Win,
    ROUND(SUM(CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS Win_Percentage
FROM matches m
JOIN venue v ON m.Venue_Id = v.Venue_Id
JOIN toss_decision td ON m.Toss_Decide = td.Toss_Id
GROUP BY v.Venue_Name, td.Toss_Name
ORDER BY v.Venue_Name, td.Toss_Name;
