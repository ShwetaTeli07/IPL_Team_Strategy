
--  Identify Top Batsmen (Consistent Performers
SELECT 
    p.Player_Name,
    ROUND(SUM(b.Runs_Scored) * 1.0 / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match,
    COUNT(DISTINCT m.Season_Id) AS Seasons_Played
FROM Ball_by_Ball b
JOIN Player p ON b.Striker = p.Player_Id
JOIN Matches m ON m.Match_Id = b.Match_Id
GROUP BY p.Player_Name
HAVING COUNT(DISTINCT m.Season_Id) >= 3
ORDER BY Avg_Runs_Per_Match DESC
LIMIT 5;


--  Identify Top Bowlers (Wicket-Takers)
SELECT 
    p.Player_Name,
    COUNT(*) AS Deliveries_Bowled,
    COUNT(w.Match_Id) AS Wickets,
    ROUND(COUNT(w.Match_Id) * 100.0 / COUNT(*), 2) AS Strike_Rate
FROM Ball_by_Ball b
JOIN Player p ON p.Player_Id = b.Bowler
LEFT JOIN wicket_taken w 
    ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id
GROUP BY p.Player_Name
HAVING COUNT(*) > 100
ORDER BY Wickets DESC
LIMIT 10;




