--  Step 1: Create a summary table with team performance
CREATE TABLE Team_Season_Performance AS
SELECT
    bb.Team_Batting AS Team_Id,
    m.Season_Id,
    SUM(bb.Runs_Scored) AS Total_Runs,
    COUNT(wt.Player_Out) AS Total_Wickets
FROM ball_by_ball bb
JOIN matches m ON bb.Match_Id = m.Match_Id
LEFT JOIN wicket_taken wt 
    ON bb.Match_Id = wt.Match_Id 
   AND bb.Over_Id = wt.Over_Id 
   AND bb.Ball_Id = wt.Ball_Id 
   AND bb.Innings_No = wt.Innings_No
GROUP BY bb.Team_Batting, m.Season_Id;


--   Duplicate into a new table to avoid MySQL join error
CREATE TABLE Team_Season_Performance_Final AS
SELECT * FROM Team_Season_Performance;

-- Join current and previous season performance
SELECT 
    curr.Team_Id,
    curr.Season_Id AS Current_Season,
    prev.Season_Id AS Previous_Season,
    curr.Total_Runs,
    prev.Total_Runs AS Prev_Total_Runs,
    curr.Total_Wickets,
    prev.Total_Wickets AS Prev_Total_Wickets,
    CASE 
        WHEN curr.Total_Runs > prev.Total_Runs AND curr.Total_Wickets > prev.Total_Wickets THEN 'Improved'
        WHEN curr.Total_Runs < prev.Total_Runs AND curr.Total_Wickets < prev.Total_Wickets THEN 'Declined'
        ELSE 'No Significant Change'
    END AS Performance_Status
FROM 
    Team_Season_Performance_Final curr
JOIN 
    Team_Season_Performance_Final prev
    ON curr.Team_Id = prev.Team_Id
   AND curr.Season_Id = prev.Season_Id + 1
ORDER BY curr.Team_Id, curr.Season_Id;
